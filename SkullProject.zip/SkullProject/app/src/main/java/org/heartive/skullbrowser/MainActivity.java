package org.heartive.skullbrowser;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.net.VpnService;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private WebView webView;
    private Button actionButton;
    private String targetStreamUrl = "https://multiembed.mov"; 
    private static final int VPN_REQUEST_CODE = 0x0F;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.fullscreen_webview);
        actionButton = findViewById(R.id.admin_action_btn);

        // Turn on advanced JavaScript support for the stream video rendering frames
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);

        webView.setWebViewClient(new MyWebViewClient());

        actionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showAdminRoutingDialog();
            }
        });

        webView.loadUrl(targetStreamUrl);
    }

    private void showAdminRoutingDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("💀 SKULL ADMIN ROUTER");
        builder.setMessage("Select your execution network layer:");

        builder.setPositiveButton("Skull Sandbox Browser + VPN", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Initialize the VPN configuration engine authorization prompt
                Intent vpnIntent = VpnService.prepare(MainActivity.this);
                if (vpnIntent != null) {
                    startActivityForResult(vpnIntent, VPN_REQUEST_CODE);
                } else {
                    onActivityResult(VPN_REQUEST_CODE, RESULT_OK, null);
                }
                
                webView.setVisibility(View.VISIBLE);
                webView.loadUrl(targetStreamUrl);
            }
        });

        builder.setNegativeButton("External Browser App", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(targetStreamUrl));
                startActivity(intent);
            }
        });

        builder.show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == VPN_REQUEST_CODE && resultCode == RESULT_OK) {
            // Permission granted by user - launch the background VPN intercept service!
            Intent intent = new Intent(this, SkullVpnService.class);
            startService(intent);
        }
    }
}
