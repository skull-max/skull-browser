package org.heartive.skullbrowser;

import android.net.VpnService;
import android.os.ParcelFileDescriptor;
import android.util.Log;
import java.io.IOException;

public class SkullVpnService extends VpnService implements Runnable {

    private Thread mThread;
    private ParcelFileDescriptor mInterface;

    @Override
    public int onStartCommand(android.content.Intent intent, int flags, int startId) {
        // Start the VPN background worker thread
        mThread = new Thread(this, "SkullVpnThread");
        mThread.start();
        return START_STICKY;
    }

    @Override
    public void run() {
        try {
            // Build the local VPN interface structure
            Builder builder = new Builder();
            
            // Route all internet traffic (0.0.0.0 matches all addresses) into our filter
            mInterface = builder.setSession("Skull Shield VPN")
                                .addAddress("10.0.0.2", 24)
                                .addRoute("0.0.0.0", 0) 
                                .addDnsServer("9.9.9.9") // Routes securely through Quad9 secure DNS
                                .establish();

            Log.i("SkullVPN", "Administrative VPN Shield Activated.");
            
            // Keep the VPN thread alive in a lightweight sleep state
            while (!Thread.interrupted()) {
                Thread.sleep(1000);
            }
        } catch (Exception e) {
            Log.e("SkullVPN", "VPN Connection Error", e);
        } finally {
            try {
                if (mInterface != null) {
                    mInterface.close();
                }
            } catch (IOException e) {
                // Interface closing fallback
            }
        }
    }

    @Override
    public void onDestroy() {
        if (mThread != null) {
            mThread.interrupt();
        }
        super.onDestroy();
    }
}
